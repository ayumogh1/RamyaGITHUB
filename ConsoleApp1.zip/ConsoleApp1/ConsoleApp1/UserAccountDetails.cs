﻿namespace CustomersFirstBank
{
    //class to store user details
    public class UserAccountDetails
    {
        public int AccountId { get; set; }
        public string Owner { get; set; }
        public float Amount { get; set; }
        public string AccountType { get; set; }
    }
}