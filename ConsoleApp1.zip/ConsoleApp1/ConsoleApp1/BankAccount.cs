﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomersFirstBank
{
    public class bankAccount : IBankAccount
    {
        List<UserAccountDetails> _accounts = new List<UserAccountDetails>();
        ReturnedVal rv = new ReturnedVal();

        public void BankAccount()
        {
            _accounts = new List<UserAccountDetails>();
        }

        public int CreateAccount(string name, string AccountType)
        {
            UserAccountDetails account = new UserAccountDetails();

            if (!String.IsNullOrEmpty(name) && !String.IsNullOrEmpty(AccountType))
            {
                account.AccountId = NextID(_accounts);
                account.Owner = name;
                account.Amount = 0;
                account.AccountType = AccountType;
                _accounts.Add(account);
                Console.WriteLine("Account Created for {0}, Account No: {1}, Initial Balance: {2}, AccountType :{3}",account.Owner,account.AccountId,account.Amount,account.AccountType);
                return account.AccountId;
            }
            else
                return 0;


        }
        public float Deposit(int? AccountID, float? amt)
        {
            int ID = 0;
            float Amount = 0;
            ID = (AccountID == null) ? rv.EnterAccountId() : AccountID ?? 0;
          

            UserAccountDetails account = rv.GetAccountById(ID, _accounts);


            while (account == null)
            {
                Console.WriteLine("Account doesn't exist");
                ID = rv.EnterAccountId();
                account = rv.GetAccountById(ID, _accounts);
            }
            Amount = (amt == null) ? rv.AmountToDeposit() : amt ?? 0;
          
            while (Amount <= 0)
            {
                Console.WriteLine("Amount cannot be less or equal than 0.");
                Amount = 0;
                Amount = rv.AmountToDeposit();
            }

            account.Amount += Amount;
            Console.WriteLine("Added {0} to account {1}, {2}", Amount, ID, account.Owner);
            Console.WriteLine("Account details for {0} after deposit : Account No: {1}, Initial Balance: {2}, AccountType :{3}", account.Owner, account.AccountId, account.Amount, account.AccountType);
            return account.Amount;
        }
        public float Withdraw(int? AccountID, float? amt)
        {
            UserAccountDetails account = new UserAccountDetails();
            int ID = 0;
            float Amount = 0;
            ID = (AccountID == null) ? rv.EnterAccountId() : AccountID ?? 0;
          
            account = rv.GetAccountById(ID, _accounts);

            while (account == null)
            {
                Console.WriteLine("Account doesn't exist");
                ID = rv.EnterAccountId();
                account = rv.GetAccountById(ID, _accounts);
            }

            Amount = (amt == null) ? rv.AmountToDeposit() : amt ?? 0;
            while (Amount <= 0)
            {
                Console.WriteLine("Amount cannot be less or equal than 0.");
                Amount = 0;
                Amount = rv.AmountToDeposit();
            }
            if (Amount > 1000)
            {
                Amount = 0;
                Console.WriteLine("you cannot withdraw more than 1000");
            }
            else if (account.Amount > Amount)
            {
                account.Amount -= Amount;

                Console.Write("Withdrawn {0} from account {1} , {2}.", Amount, ID, account.Owner);
                Console.WriteLine("Remaining: {0}", Math.Round(account.Amount, 2));
            }
            return account.Amount;
        }
        public List<float> Transfer(int? FID, int? TID, float? amt)
        {
            UserAccountDetails accountFrom = new UserAccountDetails();
            UserAccountDetails accountTo = new UserAccountDetails();
            List<float> acctAmtDet = new List<float>();
            int FromID = (FID == null) ? rv.EnterAccountId() : FID ?? 0;
            // Console.WriteLine("Enter account no. to transfer amount from");
            // int FromID = rv.EnterAccountId();
            int ToID = (TID == null) ? rv.EnterAccountId() : TID ?? 0;
           // Console.WriteLine("Enter account no. to transfer amount To");
           // int ToID = rv.EnterAccountId();
            accountFrom = rv.GetAccountById(FromID, _accounts);
            accountTo = rv.GetAccountById(ToID, _accounts);

            while (accountFrom == null)
            {
                Console.WriteLine("From Account doesn't exist");
                FromID = rv.EnterAccountId();
                accountFrom = rv.GetAccountById(FromID, _accounts);
                acctAmtDet.Add(0);
                return acctAmtDet;
            }

            while (accountTo == null)
            {
                Console.WriteLine("To Account doesn't exist");
                ToID = rv.EnterAccountId();
                accountTo = rv.GetAccountById(ToID, _accounts);
                acctAmtDet.Add(0);
                return acctAmtDet;
            }
            float Amount = (amt == null) ? rv.AmountToTransfer() : amt ?? 0;
        
            while (Amount <= 0)
            {
                Console.WriteLine("Amount cannot be less or equal than 0.");
                Amount = 0;
                Amount = rv.AmountToTransfer();
                acctAmtDet.Add(0);
                return acctAmtDet;
            }
            if (accountFrom.Amount > Amount)
            {
                accountFrom.Amount -= Amount;
                accountTo.Amount += Amount;

                Console.Write("Transfered {0} from account {1} , {2} to account {3} , {4}.", Amount, FromID, accountFrom.Owner, ToID, accountTo.Owner);
                Console.WriteLine("After transfer new balance in account {0} : {1}", FromID, Math.Round(accountFrom.Amount, 2));
                Console.WriteLine("After transfer new balance in account {0} : {1}", ToID, Math.Round(accountTo.Amount, 2));
                acctAmtDet.Add(accountFrom.Amount);
                acctAmtDet.Add(accountTo.Amount);
                return acctAmtDet;
            }
            acctAmtDet.Add(0);
            return acctAmtDet;

        }
        public int NextID(List<UserAccountDetails> account)
        {
           
            if (account == null)
            {
                return 0;
            }
            else if(account.Count == 0)
            {
                return 1;
            }
            int nextId = -1;
            foreach (UserAccountDetails a in account)
            {
                if (a.AccountId > nextId)
                {
                    nextId = a.AccountId;
                }
            }
            return nextId + 1;
        }
    }
}