﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomersFirstBank
{
    class ReturnedVal
    {
        internal int EnterAccountId()
        {
            Console.WriteLine("Account ID:");
            int ID = int.Parse(Console.ReadLine());
            return ID;
        }

        internal float AmountToDeposit()
        {
            Console.WriteLine("Type in the amount");
            float amount = float.Parse(Console.ReadLine());

            return amount;
        }
        internal float AmountToTransfer()
        {
            Console.WriteLine("Type in the amount to Transfer");
            float amount = float.Parse(Console.ReadLine());

            return amount;
        }

        internal UserAccountDetails GetAccountById(int ID, List<UserAccountDetails> _acct)
        {
            UserAccountDetails ua = _acct.Find(c => c.AccountId== ID);

            if (ua != null)
            {
                return ua;
            }
            else
            {
                return null;
            }
        }
    }

}
