﻿using System;

namespace CustomersFirstBank
{
    class Program
    {
        //This is a Console Application
        //Reads and performs action based on user input
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            bankAccount bankdetail = new bankAccount();
            ShowMenu();
            while (true)
            {
                Console.WriteLine("");
                string userInput = Console.ReadLine();
                
                switch (userInput)
                {
                    case "a":
                        
                        Console.WriteLine("Enter Account Holder Name");
                        string name = null;
                        while (name == null || name == "")
                        {
                            name = Console.ReadLine();
                        }
                        Console.WriteLine("Choose the account type -");
                        AccountType();
                       string acctType = Console.ReadLine();
                        switch(acctType)
                        {
                            case "a":
                                bankdetail.CreateAccount(name, "Checking");
                                break;
                            case "b":
                                bankdetail.CreateAccount(name, "Corporate Investment");
                                break;
                            case "c":
                                bankdetail.CreateAccount(name, "Individual Investment");
                                break;
                            default:
                                Console.WriteLine("Please select a valid option");
                                break;

                        }
                        ShowMenu();
                        break;

                    case "b":
                        bankdetail.Deposit(null,null);
                        ShowMenu();
                        break;

                    case "c":
                        bankdetail.Withdraw(null,null);
                        ShowMenu();
                        break;

                    case "d":
                        bankdetail.Transfer(null,null,null);
                        ShowMenu();
                        break;

                    default:
                        Console.WriteLine("Please select a valid option");
                        break;


                }
            }
       
        }
        public static void ShowMenu()
        {
            Console.WriteLine("a. Create Account");
            Console.WriteLine("b. Deposit");
            Console.WriteLine("c. Withdraw");
            Console.WriteLine("d. Transfer");
            Console.WriteLine("e. Exit");
        }
        public static void AccountType()
        {
            Console.WriteLine("a. Checking");
            Console.WriteLine("b. Corporate Investment");
            Console.WriteLine("c. Individual Investment");
        }

    }
}