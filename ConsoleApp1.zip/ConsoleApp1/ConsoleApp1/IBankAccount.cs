﻿using System.Collections.Generic;
namespace CustomersFirstBank
{
  // All accounts must support deposits, withdrawals, and transfers to any other type of account
   internal interface IBankAccount
    {
        //Name: Account Holder Name
        //Account Type : Type of account
        int CreateAccount(string name, string AccountType);

        //ID : Account ID 
        //Amount to deposit
        float Deposit(int? ID, float? Amount);

        //ID: Account ID
        //Amount to deposit
        float Withdraw(int? ID, float? Amount);

        //FID: From Account ID
        //TID: TO ACCOUNT ID
        //AMOUNT: Amount to transfer
        List<float> Transfer(int? FID, int? TID, float? Amount);
     

    }
}