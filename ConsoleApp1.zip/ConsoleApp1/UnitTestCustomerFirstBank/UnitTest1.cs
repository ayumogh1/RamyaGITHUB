using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CustomersFirstBank;

namespace UnitTestCustomerFirstBank
{
    [TestClass]
    public class UnitTest1
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }


        [TestMethod]
        public void TheseTestsNeedToPass()
        {//Arrange
            //Act
            //Assert
            bankAccount bankdet = new bankAccount();
            var ID = bankdet.CreateAccount("Ramya", "Checking");
            var dep1 = bankdet.Deposit(ID, 2000);
            Assert.AreEqual(dep1, 2000);

            ID = bankdet.CreateAccount("Joeseph", "Checking");
            var dep2 = bankdet.Deposit(ID, 4000);
             Assert.AreEqual(dep2, 4000);

            ID = bankdet.CreateAccount("Mary", "Checking");
            var dep3 = bankdet.Deposit(ID, 3000);
            Assert.AreEqual(dep3, 3000);

            //Withdaw from AccountID = 1 
            //var draw1 = bankdet.Withdraw(1, 1100);
            //Assert.AreEqual(dep1 - 1100, draw1);

            var draw2 = bankdet.Withdraw(2, 500);
            Assert.AreEqual(dep2 - 500, draw2);

            var trans1 = bankdet.Transfer(1, 3, 300);
            Assert.IsTrue(trans1.Count > 1);
            Assert.AreEqual(trans1[0], 2000 - 300);
            Assert.AreEqual(trans1[1], 3000 + 300);



            var x = testContextInstance.CurrentTestOutcome.ToString();
        }
        [TestMethod]
        public void TheseTestsNeedToFail_Withdraw()
        {//Arrange
            //Act
            //Assert
            bankAccount bankdet = new bankAccount();
            var ID = bankdet.CreateAccount("Ramya", "Checking");
            var dep1 = bankdet.Deposit(ID, 2000);
            Assert.AreEqual(dep1, 2000);

            ID = bankdet.CreateAccount("Joeseph", "Checking");
            var dep2 = bankdet.Deposit(ID, 4000);
            Assert.AreEqual(dep2, 4000);

            ID = bankdet.CreateAccount("Mary", "Checking");
            var dep3 = bankdet.Deposit(ID, 3000);
            Assert.AreEqual(dep3, 3000);

            //This Assert will fail becoz, the amount trying to withdraw is greater than 1000
            var draw2 = bankdet.Withdraw(2, 1200);
            Assert.AreEqual(dep2 - 1200, draw2);

            var trans1 = bankdet.Transfer(1, 3, 7000);
            Assert.IsTrue(trans1.Count > 1);
            Assert.AreEqual(trans1[0], 2000 - 300);
            Assert.AreEqual(trans1[1], 3000 + 300);


        }

        [TestMethod]
        public void TheseTestsNeedToFail_Transfer()
        {//Arrange
            //Act
            //Assert
            bankAccount bankdet = new bankAccount();
            var ID = bankdet.CreateAccount("Ramya", "Checking");
            var dep1 = bankdet.Deposit(ID, 2000);
            Assert.AreEqual(dep1, 2000);

            ID = bankdet.CreateAccount("Joeseph", "Checking");
            var dep2 = bankdet.Deposit(ID, 4000);
            Assert.AreEqual(dep2, 4000);

            ID = bankdet.CreateAccount("Mary", "Checking");
            var dep3 = bankdet.Deposit(ID, 3000);
            Assert.AreEqual(dep3, 3000);

         
            //This will fail as I am trying to transfer more than whats in the account
            //Cannot Overdraft an account
            var trans1 = bankdet.Transfer(1, 3, 7000);
            Assert.IsTrue(trans1.Count > 1);
            Assert.AreEqual(trans1[0], 2000 - 7000);
            Assert.AreEqual(trans1[1], 3000 + 7000);


        }
    }
}
